import json
import boto3
import os

# Assume execution role
ASSUME_EXECUTION_ROLE = os.environ['ASSUME_EXECUTION_ROLE']
TASK_DEFINITION = os.environ['TASK_DEFINITION']
PRIVATE_SUBNETS = os.environ['PRIVATE_SUBNETS']
TASK_NAME = os.environ['TASK_NAME']
MEMBER_ACCOUNTS = os.environ['MEMBER_ACCOUNTS']
MEMBER_REGIONS = os.environ['MEMBER_REGIONS']
TABLE = os.environ['TABLE']


def lambda_handler(event, context):
    client = boto3.client('ecs')
    response = client.run_task(
        cluster='SSM',
        launchType='FARGATE',
        taskDefinition=TASK_DEFINITION,
        count=1,
        platformVersion='LATEST',
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': PRIVATE_SUBNETS.split(','),
                'assignPublicIp': 'DISABLED'
            }
        },
        overrides={
            'containerOverrides': [
                {
                    'name': TASK_NAME,
                    'environment': [
                        {
                            'name': 'ASSUME_EXECUTION_ROLE',
                            'value': ASSUME_EXECUTION_ROLE
                        },
                        {
                            'name': 'MEMBER_ACCOUNTS',
                            'value': MEMBER_ACCOUNTS
                        },
                        {
                            'name': 'MEMBER_REGIONS',
                            'value': MEMBER_REGIONS
                        },
                        {
                            'name': 'TABLE',
                            'value': TABLE
                        },
                    ],
                },
            ]
        }
    )

    print('response', response)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
